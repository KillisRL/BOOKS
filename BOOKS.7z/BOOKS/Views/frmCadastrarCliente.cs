﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BOOKS.Controllers;
using BOOKS.Models;
using BOOKS.Services;

namespace BOOKS.Views
{
    public partial class frmCadastrarCliente : Form
    {
        AcaoNaTela acaoSelecionada;
        Cliente clienteSelecionado;

        [Obsolete]
        public frmCadastrarCliente(AcaoNaTela acaoTela, Cliente cliente)
        {
            InitializeComponent();
 
            acaoSelecionada = acaoTela;
            clienteSelecionado = cliente;

            if (acaoSelecionada == AcaoNaTela.Inserir)
                this.Text = "Cadastrar Cliente";
            else
            {
                CarregarDados();

                if (acaoSelecionada == AcaoNaTela.Alterar)
                    this.Text = "Alterar Cliente";
                else
                {
                    this.Text = "Visualizar Cliente";
                    DesabilitarCampos();
                }
            }
        }

        private void CarregarDados()
        {
            txtId.Text = clienteSelecionado.ClienteID.ToString();
            txtNome.Text = clienteSelecionado.ClienteNome;
            txtEmail.Text = clienteSelecionado.Email;
            mskCPF.Text = clienteSelecionado.ClienteCPF;
            txtTelefone.Text = clienteSelecionado.ClienteTelefone;
        }

        private void DesabilitarCampos()
        {
            txtNome.ReadOnly = true;
            txtEmail.ReadOnly = true;
            mskCPF.ReadOnly = true;
            txtTelefone.ReadOnly = true;
            btnSalvar.Visible = false;
            btnCancelar.Visible = false;
        }


        [Obsolete]
        private void Salvar()
        {
            //A validação vem aqui primeiro

            if (!string.IsNullOrEmpty(txtNome.Text))
            {
                //Para salvar o cliente, é precisa instanciar
                //o objeto Cliente, e preecnher com as informações
                //que o usuário informou na tela
                //Após é nescessario utilizar a camada Controller
                //para salvar o registro no banco de dados
                Cliente cliente = new Cliente();

                cliente.ClienteNome = txtNome.Text;

                cliente.Email = txtEmail.Text;

                //o CPF utiliza um campo do tipo MASK
                //por tanto a pontução é informada de forma
                //automatica, antes de gravar no banco
                //é preciso remover as pontuações
                //utilizando o Replace

                cliente.ClienteCPF = mskCPF.Text.Replace(".", "");
                cliente.ClienteCPF = cliente.ClienteCPF.Replace(",", "");
                cliente.ClienteCPF = cliente.ClienteCPF.Replace("-", "");

                cliente.ClienteTelefone = txtTelefone.Text;

                ClienteControle clienteControle =
                    new ClienteControle();


                int idCadastro = 0;

                if (acaoSelecionada == AcaoNaTela.Inserir)
                    idCadastro = clienteControle.Inserir(cliente);
                else
                {
                    cliente.ClienteID = int.Parse(txtId.Text);
                    idCadastro = clienteControle.Alterar(cliente);
                }

                if (idCadastro > 0)
                {
                    //o txtID sempre estara vazio quando for 
                    //um cadastro novo
                    //caso seja uma alteração o campo irá apresenta
                    //o ID do registro
                    //por tanto se o campo ja esta preenchido
                    //não preciso atribuir o valor retornado
                    //do banco de dados
                    //Porém se for um cadastro novo
                    //é preciso apresentar o ID do novo cadastro
                    //no txtID
                    if (string.IsNullOrEmpty(txtId.Text))
                        txtId.Text = idCadastro.ToString();

                    MessageBox.Show("Registro salvo com sucesso!",
                        "Informação", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Falha ao salvar registro",
                       "Erro", MessageBoxButtons.OK,
                       MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Preencha os campos corretamente",
                    "Atenção", MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
        }

        private void frmClienteCadastroView_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (acaoSelecionada != AcaoNaTela.Visualizar)
                if (MessageBox.Show("Deseja realmente sair?", "Confirmação...",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                    e.Cancel = true;
        }

        [Obsolete]
        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            Salvar();
            Close();
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
                this.Close();
            
        }
    }
}

