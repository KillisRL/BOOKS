﻿using BOOKS.Controllers;
using BOOKS.Models;
using BOOKS.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace ProjetoPOO.Views
{
    public partial class frmPedidoSelecaoView : Form
    {
        private Panel pnlPeriodo;
        private DateTimePicker dtpFinal;
        private Label label5;
        private Label label6;
        private DateTimePicker dtpInicial;
        private ComboBox cbxStatus;
        private Label lblFiltro;
        private TextBox txtCodigo;
        private ComboBox cbxFiltro;
        private DataGridView dgvRegistros;
        private DataGridViewTextBoxColumn colId;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn colNome;
        private DataGridViewTextBoxColumn colTelefone;
        private Button btnExcluir;
        private Button btnVisualizar;
        private Button btnPesquisar;
        private Label label1;

        public frmPedidoSelecaoView()
        {
            InitializeComponent();
            dgvRegistros.AutoGenerateColumns = false;
        }
        private void dgvRegistros_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

        }

        #region Eventos
        private void frmPedidoSelecaoView_Load(object sender, EventArgs e)
        {
            Pesquisar();
            OcultarFiltroTodos();
            cbxFiltro.SelectedIndex = 4;
            cbxStatus.SelectedIndex = 1;
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            Pesquisar();
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            AlterarStatus(true);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            AlterarStatus(false);
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Excluir();
        }

        private void btnVisualizar_Click(object sender, EventArgs e)
        {
            ChamarTelaVisualizacao();
        }
        #endregion

        #region Métodos

        #region CarregarPropriedade
        private object CarregarPropriedade(object propriedade, string nomeDaPropriedade)
        {
            try
            {
                object retorno = "";

                if (nomeDaPropriedade.Contains("."))
                {
                    PropertyInfo[] propertyInfoArray;
                    string propriedadeAntesDoPonto;

                    propriedadeAntesDoPonto = nomeDaPropriedade.Substring(0, nomeDaPropriedade.IndexOf("."));

                    if (propriedade != null)
                    {
                        propertyInfoArray = propriedade.GetType().GetProperties();

                        foreach (PropertyInfo propertyInfo in propertyInfoArray)
                        {
                            if (propertyInfo.Name == propriedadeAntesDoPonto)
                            {
                                retorno = CarregarPropriedade(propertyInfo.GetValue(propriedade, null),
                                    nomeDaPropriedade.Substring(nomeDaPropriedade.IndexOf(".") + 1));
                                break;
                            }
                        }
                    }
                }
                else
                {
                    Type typeProperty;
                    PropertyInfo propertyInfo;

                    if (propriedade != null)
                    {
                        typeProperty = propriedade.GetType();
                        propertyInfo = typeProperty.GetProperty(nomeDaPropriedade);
                        retorno = propertyInfo.GetValue(propriedade, null);
                    }
                }
                return retorno;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Atenção...", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
        }
        #endregion
        private void Pesquisar()
        {
            int id = 0;

            PedidoController pedidoController = new PedidoController();
            PedidoColecao pedidoCollection = new PedidoColecao();

            dgvRegistros.DataSource = null;

            switch (cbxFiltro.SelectedIndex)
            {
                case 0:
                    pedidoCollection = pedidoController.ConsultarPorPeriodo(dtpInicial.Value, dtpFinal.Value);
                    break;
                case 1:
                    {
                        if (int.TryParse(txtCodigo.Text, out id))
                            pedidoCollection = pedidoController.ConsultarPorCampo("id_cliente", id.ToString());
                    }
                    break;
                case 2:
                    {
                        if (int.TryParse(txtCodigo.Text, out id))
                            pedidoCollection = pedidoController.ConsultarPorCampo("id_pedido", id.ToString());
                    }
                    break;
                case 3:
                    {
                        string status = "";
                        switch (cbxStatus.SelectedIndex)
                        {
                            case 0:
                                status = "F";
                                break;
                            case 1:
                                status = "P";
                                break;
                            case 2:
                                status = "C";
                                break;
                        }

                        pedidoCollection = pedidoController.ConsultarPorCampo("status", status);
                    }
                    break;
                case 4:
                    pedidoCollection = pedidoController.ConsultarTodos();
                    break;
            }

            dgvRegistros.DataSource = pedidoCollection;
            dgvRegistros.Update();
            dgvRegistros.Refresh();
        }

        private Pedido RecuperarRegistro()
        {
            if (dgvRegistros.SelectedRows.Count == 0)
            {
                MessageBox.Show("Nenhum registro selecionado.", "Informação",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return null;
            }
            else
            {
                return dgvRegistros.SelectedRows[0].DataBoundItem as Pedido;
            }
        }

        private void ChamarTelaVisualizacao()
        {
            Pedido pedidoSelecionado = RecuperarRegistro();
            if (pedidoSelecionado != null)
            {
                frmPedidoVisualizacaoView frm = new frmPedidoVisualizacaoView(pedidoSelecionado);
                frm.ShowDialog();
            }
        }

        private void AlterarStatus(bool IsFinalizar)
        {
            Pedido pedidoSelecionado = RecuperarRegistro();

            string statusTratado = IsFinalizar ? "Finalizar" : "Cancelar";
            string statusRetorno = IsFinalizar ? "Finalizado" : "Cancelado";
            char status = IsFinalizar ? 'F' : 'C';

            if (pedidoSelecionado != null)
            {
                if (pedidoSelecionado.SituacaPedido != 'P')
                    MessageBox.Show($"Não é possível {statusTratado} um registro {pedidoSelecionado.StatusTratado}.", "Atenção",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                {
                    PedidoController pedidoController = new PedidoController();

                    if (MessageBox.Show($"Deseja realmente {statusTratado} este pedido?", "Confirmação...",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {

                        if (pedidoController.AlterarStatus(pedidoSelecionado.PedidoID, status) > 0)
                        {
                            MessageBox.Show($"Pedido {statusRetorno} com sucesso.", "Informação...",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Pesquisar();
                        }
                        else
                            MessageBox.Show("O Pedido não foi encontrado no banco de dados.", "Atenção...",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }

            }
        }

        private void Excluir()
        {
            Pedido pedidoSelecionado = RecuperarRegistro();

            if (pedidoSelecionado != null)
            {
                if (pedidoSelecionado.SituacaPedido != 'P')
                    MessageBox.Show($"Não é possível excluir um registro {pedidoSelecionado.StatusTratado}.", "Atenção",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                {
                    if (MessageBox.Show("Deseja realmente excluir o registro?", "Confirmação",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {

                        PedidoController pedidoController = new PedidoController();

                        if (pedidoController.Apagar(pedidoSelecionado.SituacaPedido) > 0)
                        {
                            MessageBox.Show("Registro excluído com sucesso.", "Informação",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);

                            Pesquisar();
                        }
                        else
                            MessageBox.Show("Não foi possível excluir o regsitro.", "Atenção",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AjustarFiltros();
        }

        private void OcultarFiltroTodos()
        {
            pnlPeriodo.Visible = false;
            cbxStatus.Visible = false;
            txtCodigo.Visible = false;
            lblFiltro.Visible = false;
        }

        private void AjustarFiltros()
        {
            OcultarFiltroTodos();

            lblFiltro.Visible = true;
            switch (cbxFiltro.SelectedIndex)
            {
                case 0:
                    {
                        lblFiltro.Text = "Período";
                        pnlPeriodo.Visible = true;
                    }
                    break;
                case 1:
                case 2:
                    {
                        lblFiltro.Text = "Código";
                        txtCodigo.Visible = true;
                    }
                    break;
                case 3:
                    {
                        lblFiltro.Text = "Status";
                        cbxStatus.Visible = true;
                    }
                    break;
                case 4:
                    lblFiltro.Visible = false;
                    break;
            }
        }
        #endregion

        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlPeriodo = new System.Windows.Forms.Panel();
            this.dtpFinal = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpInicial = new System.Windows.Forms.DateTimePicker();
            this.cbxStatus = new System.Windows.Forms.ComboBox();
            this.lblFiltro = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.cbxFiltro = new System.Windows.Forms.ComboBox();
            this.dgvRegistros = new System.Windows.Forms.DataGridView();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTelefone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnVisualizar = new System.Windows.Forms.Button();
            this.btnPesquisar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlPeriodo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegistros)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlPeriodo
            // 
            this.pnlPeriodo.Controls.Add(this.dtpFinal);
            this.pnlPeriodo.Controls.Add(this.label5);
            this.pnlPeriodo.Controls.Add(this.label6);
            this.pnlPeriodo.Controls.Add(this.dtpInicial);
            this.pnlPeriodo.Location = new System.Drawing.Point(119, 26);
            this.pnlPeriodo.Name = "pnlPeriodo";
            this.pnlPeriodo.Size = new System.Drawing.Size(282, 26);
            this.pnlPeriodo.TabIndex = 46;
            // 
            // dtpFinal
            // 
            this.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFinal.Location = new System.Drawing.Point(168, 3);
            this.dtpFinal.Name = "dtpFinal";
            this.dtpFinal.Size = new System.Drawing.Size(102, 20);
            this.dtpFinal.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(136, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 13);
            this.label5.TabIndex = 31;
            this.label5.Text = "Até:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-2, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 13);
            this.label6.TabIndex = 30;
            this.label6.Text = "De:";
            // 
            // dtpInicial
            // 
            this.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInicial.Location = new System.Drawing.Point(28, 3);
            this.dtpInicial.Name = "dtpInicial";
            this.dtpInicial.Size = new System.Drawing.Size(102, 20);
            this.dtpInicial.TabIndex = 29;
            // 
            // cbxStatus
            // 
            this.cbxStatus.FormattingEnabled = true;
            this.cbxStatus.Items.AddRange(new object[] {
            "Finalizado",
            "Pendente",
            "Cancelado"});
            this.cbxStatus.Location = new System.Drawing.Point(120, 28);
            this.cbxStatus.Name = "cbxStatus";
            this.cbxStatus.Size = new System.Drawing.Size(101, 21);
            this.cbxStatus.TabIndex = 45;
            // 
            // lblFiltro
            // 
            this.lblFiltro.AutoSize = true;
            this.lblFiltro.Location = new System.Drawing.Point(116, 9);
            this.lblFiltro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFiltro.Name = "lblFiltro";
            this.lblFiltro.Size = new System.Drawing.Size(31, 13);
            this.lblFiltro.TabIndex = 44;
            this.lblFiltro.Text = "Tipo:";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(119, 28);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(103, 20);
            this.txtCodigo.TabIndex = 43;
            // 
            // cbxFiltro
            // 
            this.cbxFiltro.FormattingEnabled = true;
            this.cbxFiltro.Items.AddRange(new object[] {
            "Período",
            "Cliente",
            "Código",
            "Status",
            "Todos"});
            this.cbxFiltro.Location = new System.Drawing.Point(11, 28);
            this.cbxFiltro.Name = "cbxFiltro";
            this.cbxFiltro.Size = new System.Drawing.Size(102, 21);
            this.cbxFiltro.TabIndex = 42;
            // 
            // dgvRegistros
            // 
            this.dgvRegistros.AllowUserToAddRows = false;
            this.dgvRegistros.AllowUserToDeleteRows = false;
            this.dgvRegistros.AllowUserToOrderColumns = true;
            this.dgvRegistros.AllowUserToResizeColumns = false;
            this.dgvRegistros.AllowUserToResizeRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvRegistros.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvRegistros.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRegistros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRegistros.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colId,
            this.Column2,
            this.Column1,
            this.colNome,
            this.colTelefone});
            this.dgvRegistros.Location = new System.Drawing.Point(11, 55);
            this.dgvRegistros.MultiSelect = false;
            this.dgvRegistros.Name = "dgvRegistros";
            this.dgvRegistros.ReadOnly = true;
            this.dgvRegistros.RowHeadersVisible = false;
            this.dgvRegistros.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRegistros.Size = new System.Drawing.Size(582, 272);
            this.dgvRegistros.TabIndex = 41;
            // 
            // colId
            // 
            this.colId.DataPropertyName = "IdPedido";
            this.colId.HeaderText = "Código";
            this.colId.Name = "colId";
            this.colId.ReadOnly = true;
            this.colId.Width = 60;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "StatusTratado";
            this.Column2.HeaderText = "Status";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 70;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "DtHora";
            this.Column1.HeaderText = "Data";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // colNome
            // 
            this.colNome.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.colNome.DataPropertyName = "Cliente.IdNomeCliente";
            this.colNome.HeaderText = "Nome";
            this.colNome.Name = "colNome";
            this.colNome.ReadOnly = true;
            // 
            // colTelefone
            // 
            this.colTelefone.DataPropertyName = "ValorTotal";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.Format = "N2";
            dataGridViewCellStyle12.NullValue = "0,00";
            this.colTelefone.DefaultCellStyle = dataGridViewCellStyle12;
            this.colTelefone.HeaderText = "Valor";
            this.colTelefone.Name = "colTelefone";
            this.colTelefone.ReadOnly = true;
            this.colTelefone.Width = 80;
            // 
            // btnExcluir
            // 
            this.btnExcluir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExcluir.Location = new System.Drawing.Point(437, 334);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(75, 23);
            this.btnExcluir.TabIndex = 38;
            this.btnExcluir.Text = "Excluir";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click_1);
            // 
            // btnVisualizar
            // 
            this.btnVisualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnVisualizar.Location = new System.Drawing.Point(518, 334);
            this.btnVisualizar.Name = "btnVisualizar";
            this.btnVisualizar.Size = new System.Drawing.Size(75, 23);
            this.btnVisualizar.TabIndex = 37;
            this.btnVisualizar.Text = "Visualizar";
            this.btnVisualizar.UseVisualStyleBackColor = true;
            this.btnVisualizar.Click += new System.EventHandler(this.btnVisualizar_Click_1);
            // 
            // btnPesquisar
            // 
            this.btnPesquisar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPesquisar.Location = new System.Drawing.Point(518, 26);
            this.btnPesquisar.Name = "btnPesquisar";
            this.btnPesquisar.Size = new System.Drawing.Size(75, 23);
            this.btnPesquisar.TabIndex = 36;
            this.btnPesquisar.Text = "Pesquisar";
            this.btnPesquisar.UseVisualStyleBackColor = true;
            this.btnPesquisar.Click += new System.EventHandler(this.btnPesquisar_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "Tipo:";
            // 
            // frmPedidoSelecaoView
            // 
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.pnlPeriodo);
            this.Controls.Add(this.cbxStatus);
            this.Controls.Add(this.lblFiltro);
            this.Controls.Add(this.txtCodigo);
            this.Controls.Add(this.cbxFiltro);
            this.Controls.Add(this.dgvRegistros);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnVisualizar);
            this.Controls.Add(this.btnPesquisar);
            this.Controls.Add(this.label1);
            this.Name = "frmPedidoSelecaoView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.pnlPeriodo.ResumeLayout(false);
            this.pnlPeriodo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRegistros)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void btnPesquisar_Click_1(object sender, EventArgs e)
        {
            Pesquisar();
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            Excluir();
        }

        private void btnVisualizar_Click_1(object sender, EventArgs e)
        {
            ChamarTelaVisualizacao();
        }
    }
}
