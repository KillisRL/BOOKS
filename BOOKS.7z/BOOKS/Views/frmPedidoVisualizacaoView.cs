﻿using BOOKS.Controllers;
using BOOKS.Models;
using System;
using System.Windows.Forms;
using System.Reflection;

namespace BOOKS.Views
{
    public partial class frmPedidoVisualizacaoView : Form
    {
        Pedido pedidoSelecionado;

        PedidoItemController pedidoItemController = new PedidoItemController();

        public frmPedidoVisualizacaoView()
        {
            InitializeComponent();
        }
        public frmPedidoVisualizacaoView(Pedido pedido) : this()
        {
            pedidoSelecionado = pedido;
            InitializeComponent();
            dgvPedidoItens.AutoGenerateColumns = false;
        }

        [Obsolete]
        private void frmPedidoVisualizacaoView_Load(object sender, EventArgs e)
        {
            CarregarPropriedades();
            CarregarProdutos();
        }

        private void CarregarPropriedades()
        {
            txtIdCliente.Text = pedidoSelecionado.cliente.ClienteID.ToString();
            txtNomeCliente.Text = pedidoSelecionado.cliente.ClienteNome;
            txtIdPedido.Text = pedidoSelecionado.PedidoID.ToString();
            txtDataHora.Text = pedidoSelecionado.DataHora.ToShortDateString();
            lblValorTotal.Text = "Valor total: R$ " + string.Format("{0:N2}", pedidoSelecionado.ValorTotal);
        }

        [Obsolete]
        private void CarregarProdutos()
        {
            dgvPedidoItens.DataSource = null;
            dgvPedidoItens.DataSource = pedidoItemController.ConsultarTodosItensDoPedido(pedidoSelecionado.PedidoID);
            dgvPedidoItens.Update();
            dgvPedidoItens.Refresh();
        }
    }
}
