﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKS.Models
{
    public class PedidoItem
    {
        public int PedidoItemID { get; set; }
        public int PedidoID { get; set; }
        public Pedido pedido { get; set; }
        public Livro livro { get; set; }
        public int Quantidade { get; set; }
        public decimal ValorUnitario { get; set;}
        public decimal ValorTotal { get; set; }
    }
}
