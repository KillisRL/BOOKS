﻿using System;

namespace BOOKS.Models
{
    public class Pedido
    {
        public int PedidoID { get; set; }
        public DateTime DataHora { get; set; }
        public Cliente cliente { get; set; }
        public char SituacaPedido { get; set; }
        public string StatusTratado 
        {
            get 
            {
                switch(SituacaPedido)
                {
                    case 'P' :
                        return "Pendente";
                        break;

                    case 'F':
                        return "Finalizado";
                        break;
                    case 'C':
                        return "Cancelado";
                        break;
                    default:
                        return "Desconhecido";
                        break;
                }
                
            }
        }
        public Decimal ValorTotal { get; set; }
    }
}
