﻿using System.Collections.Generic;

namespace BOOKS.Models
{
    public class PedidoColecao : List<Pedido>
    {
    }
}
