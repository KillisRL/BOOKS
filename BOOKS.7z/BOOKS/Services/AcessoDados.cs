﻿// vamos importar biblioteca no Banco
using System;
using System.Data;
using System.Data.SqlClient;


namespace BOOKS.Services
{
    public class AcessoDados
    {
        //metodo para conectar com o banco de dados
        private SqlConnection CriarConexao()
        {
            SqlConnection conexao = new SqlConnection();
            //aqui vamos criar a string de conexao para conectar no banco
            //Data Source = servidor
            //Initial Catalog = Nome do Banco 
            //Integrated Security Autenticação do Windows
            //User Instance vai pegar o usuário que está logado na máquina
            conexao.ConnectionString = "Data Source=KILLISPC;" + "Initial Catalog=BOOKS;" + "Integrated Security=SSPI;" + "User Instance=false;";

            conexao.Open();// Abrir a conexão 
            return conexao;

        }

        //aqui vamos criar uma varivel golbal para armazenar os parametros do sql.
        private SqlParameterCollection sqlParameterCollection = new SqlCommand().Parameters;

        public void LimparParametros()
        {
            sqlParameterCollection.Clear();
        }
        public void AdicionarParametro(string nomeParametro, object valorParametro)
        {
            sqlParameterCollection.Add(new SqlParameter(nomeParametro, valorParametro) );
        }

        //aqui vamos começar as manipulações INSERT - UPDATE - DELETE
        [Obsolete]
        public int ExecutarManipulacao(
            CommandType commandType,
            string nomeStoredProcedureOuTextpSql)
        {
            try
            {
                SqlConnection sqlConnection = CriarConexao();
                SqlCommand sqlCommand = sqlConnection.CreateCommand();

                sqlCommand.CommandType = commandType;
                sqlCommand.CommandText = nomeStoredProcedureOuTextpSql;

                foreach (SqlParameter sqlParameter in sqlParameterCollection)
                {
                    sqlCommand.Parameters.Add(
                        new SqlParameter(sqlParameter.ParameterName,
                                            sqlParameter.Value));
                }

                //Executa o comando SQL e retorna quantas linhas afetadas
                return sqlCommand.ExecuteNonQuery();
            }
            //Adicionar a biblioteca using System;
            catch (Exception ex)
            {
                //Retorno o erro a onde o Método foi chamado
                throw new Exception("Houve uma falha ao execuar o " +
                    "comando no banco de dados.\r\n" +
                    "Mensagem original: " + ex.Message);
            }
        }

        //Metodo para realizar as consultas no banco de dados
        [Obsolete]
        public DataTable ExecutarConsulta(CommandType commandType, string nomeStoredProcedureOuTextpSql)
        {
            try
            {
                SqlConnection sqlConnection = CriarConexao();
                SqlCommand sqlCommand = sqlConnection.CreateCommand();

                sqlCommand.CommandType = commandType;
                sqlCommand.CommandText = nomeStoredProcedureOuTextpSql;

                foreach (SqlParameter sqlParameter
                    in sqlParameterCollection)
                {
                    sqlCommand.Parameters.Add(
                        new SqlParameter(sqlParameter.ParameterName,
                                            sqlParameter.Value));
                }

                //O C# precisa que o retorno do banco de dados serja 
                //convertido para um objeto. Para isso ele utiliza
                //o SqlDataAdapter, que irá "adaptar" p retorno
                //da consulta para um objeto do tipo DataTabel.
                //É o DataTable que será utlizado dentro do C#
                //Ou seja eu converto a tabela de dados sql
                //em tabale de dados C#
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                DataTable dataTable = new DataTable();

                //Nesse ponto o comando SQL é executado
                //e o resultado é "adaptado" (convertido)
                //para o objeto dataTabela
                sqlDataAdapter.Fill(dataTable);

                return dataTable;
            }
            catch (Exception ex)
            {
                //Retorno o erro a onde o Método foi chamado
                throw new Exception("Houve uma falha ao execuar o " +
                    "comando no banco de dados.\r\n" +
                    "Mensagem original: " + ex.Message);
            }
        }

        //Metodo consulta escalar para retornar uma única informação
        [Obsolete]
        public object ExecutarConsultaEsacalar(CommandType commandType, string nomeStoredeOuTextoSql)
        {
            try
            {
                //abrimos a conexão com o banco aqui
                SqlConnection sqlConnection = CriarConexao();
                //criar a variavél do comando que sera executado
                SqlCommand sqlCommand = sqlConnection.CreateCommand();
                //aqui vamos definir o tipo de comando 
                sqlCommand.CommandType = commandType;
                sqlCommand.CommandText = nomeStoredeOuTextoSql;
                //aqui vamos carregar os parametro

                foreach (SqlParameter sqlParameter in sqlParameterCollection)
                {
                    sqlCommand.Parameters.Add(sqlParameter.ParameterName, sqlParameter.Value);


                }
                return sqlCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                //aqui crio a mensagem tratada
                //\r\b =  quebra de linha
                throw new Exception("Houve uma falha" + "a consult escalar no  de dados" + "\r\n" + "Mensagem original" + ex.Message);
            }
        }
    }
}