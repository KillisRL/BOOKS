﻿using BOOKS.Models;
using BOOKS.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKS.Controllers
{
    public class livroController
    {
        AcessoDados dataBase = new AcessoDados();

        public int Inserir(Livro livro)
        {
            string queryInserir = "INSERT INTO tblLivro (LivroNome, CodigoISBN, QuantidadePaginas, Preco, NomeAutor,LivroGenero ) " +
                "VALUES (@LivroNome, @CodigoISBN, @QuantidadePaginas, @Preco, @NomeAutor, @LivroGenero );";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@LivroNome", livro.LivroNome);
            dataBase.AdicionarParametro("@CodigoISBN", livro.CodigoISBN);
            dataBase.AdicionarParametro("@QuantidadePaginas", livro.QuantidadePaginas);
            dataBase.AdicionarParametro("@Preco", livro.Preco);
            dataBase.AdicionarParametro("@NomeAutor", livro.NomeAutor);
            dataBase.AdicionarParametro("@LivroGenero", livro.LivroGenero);

            dataBase.ExecutarManipulacao(CommandType.Text, queryInserir);
            return Convert.ToInt32(dataBase.ExecutarConsultaEsacalar(CommandType.Text, "SELECT MAX(LivroID) FROM tblLivro"));
        }

        public int Alterar(Livro livro)
        {
            string queryInserir = "UPDATE tblLivro SET LivroNome = @LivroNome, CodigoISBN = @CodigoISBN, " +
                "QuantidadePaginas = @QuantidadePaginas, Preco = @Preco, NomeAutor = @NomeAutor, LivroGenero = @LivroGenero WHERE LivroID = @LivroID";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@LivroNome", livro.LivroNome);
            dataBase.AdicionarParametro("@CodigoISBN", livro.CodigoISBN);
            dataBase.AdicionarParametro("@QuantidadePaginas", livro.QuantidadePaginas);
            dataBase.AdicionarParametro("@Preco", livro.Preco);
            dataBase.AdicionarParametro("@NomeAutor", livro.NomeAutor);
            dataBase.AdicionarParametro("@LivroGenero", livro.LivroGenero);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryInserir);
        }

        public int Apagar(int Idlivro)
        {
            string queryInserir = "DELETE FROM tblLivro  WHERE LivroID = @LivroID";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@LivroID", Idlivro);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryInserir);
        }

        public LivroColecao ConsultarTodos()
        {
            LivroColecao livroColecao = new LivroColecao();
            string queryConsulta = "SELECT * FROM livro ORDER BY descricao";

            DataTable dataTable = dataBase.ExecutarConsulta(CommandType.Text, queryConsulta);

            foreach (DataRow dataRow in dataTable.Rows)
            {
                Livro livro = new Livro();
                livro.LivroID = Convert.ToInt32(dataRow["LivroID"]);
                livro.LivroNome = Convert.ToString(dataRow["LivroNome"]);
                livro.CodigoISBN = Convert.ToInt32(dataRow["CodigoISBN"]);
                livro.QuantidadePaginas = Convert.ToInt32(dataRow["QuantidadePaginas"]);
                livro.Preco = Convert.ToDecimal(dataRow["Preco"]);
                livro.NomeAutor = Convert.ToString(dataRow["NomeAutor"]);
                livro.LivroGenero = Convert.ToString(dataRow["LivroGenero"]);


                livroColecao.Add(livro);
            }
            return livroColecao;
        }

        public Livro ConsultarPorId(int Idlivro)
        {
            string queryConsulta = "SELECT * FROM tblLivro WHERE LivroID = @LivroID";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@LivroID", Idlivro);

            DataTable dataTable = dataBase.ExecutarConsulta(CommandType.Text, queryConsulta);

            // Verifica se a consulta retornou resultados
            if (dataTable.Rows.Count == 0)
            {
                return null; // Retorna null se o cliente não foi encontrado
            }

            Livro livro = new Livro
            {
                LivroID = Convert.ToInt32(dataTable.Rows[0]["LivroID"]),
                LivroNome = Convert.ToString(dataTable.Rows[0]["LivroNome"]),
                CodigoISBN = Convert.ToInt32(dataTable.Rows[0]["CodigoISBN"]),
                QuantidadePaginas = Convert.ToInt32(dataTable.Rows[0]["QuantidadePaginas"]),
                Preco = Convert.ToDecimal(dataTable.Rows[0]["Preco"]),
                NomeAutor = Convert.ToString(dataTable.Rows[0]["NomeAutor"]),
                LivroGenero = Convert.ToString(dataTable.Rows[0]["LivroGenero"])
            };

            return livro;
        }


        public LivroColecao ConsultarPorDescricao(string Descricao)
        {
            LivroColecao livroColecao = new LivroColecao();
            string queryConsulta = "SELECT * FROM tblLivro WHERE LivroNome LIKE '%' + @LivroNome + '%' ORDER BY LivroNome";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@LivroNome", Descricao);

            DataTable dataTable = dataBase.ExecutarConsulta(CommandType.Text, queryConsulta);

            foreach (DataRow dataRow in dataTable.Rows)
            {
                Livro livro = new Livro();
                livro.LivroID = Convert.ToInt32(dataRow["LivroID"]);
                livro.LivroNome = Convert.ToString(dataRow["LivroNome"]);
                livro.CodigoISBN = Convert.ToInt32(dataRow["CodigoISBN"]);
                livro.QuantidadePaginas = Convert.ToInt32(dataRow["QuantidadePaginas"]);
                livro.Preco = Convert.ToDecimal(dataRow["Preco"]);
                livro.NomeAutor = Convert.ToString(dataRow["NomeAutor"]);
                livro.LivroGenero = Convert.ToString(dataRow["LivroGenero"]);

                livroColecao.Add(livro);
            }
            return livroColecao;
        }

        internal void Add(Livro produto)
        {
            throw new NotImplementedException();
        }
    }
}
