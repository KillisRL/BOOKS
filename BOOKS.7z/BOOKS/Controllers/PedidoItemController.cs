﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using BOOKS.Models;
using BOOKS.Services;
using System.Data.SqlClient;

namespace BOOKS.Controllers
{

    public class PedidoItemController
    {
        AcessoDados dataBase = new AcessoDados();

        [Obsolete]
        public int Inserir(PedidoItem pedidoItem)
        {
            string queryInserir = "INSERT INTO tblPedidoItem (PedidoID, LivroID, Quantidade, ValorTotal, ValorUnitario) " +
                "VALUES (@IdPedido, @IdProduto, @Quantidade, @ValorTotal, @ValorUnitario);";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", pedidoItem.pedido.PedidoID);
            dataBase.AdicionarParametro("@IdProduto", pedidoItem.livro.LivroID);
            dataBase.AdicionarParametro("@Quantidade", pedidoItem.Quantidade);
            dataBase.AdicionarParametro("@ValorUnitario", pedidoItem.ValorUnitario);
            dataBase.AdicionarParametro("@ValorTotal", pedidoItem.ValorTotal);

            dataBase.ExecutarManipulacao(CommandType.Text, queryInserir);

            return Convert.ToInt32(dataBase.ExecutarConsultaEsacalar(CommandType.Text, "SELECT MAX(PedidoItemID) FROM tblPedidoItem"));

        }

        [Obsolete]
        public int Alterar(PedidoItem pedidoItem)
        {
            string queryAlterar = "UPDATE tblPedidoItem SET LivroID = @IdProduto, Quantidade = @Quantidade, " +
                "ValorUnitario = @ValorUnitario, ValorTotal = @ValorTotal WHERE PedidoID = @IdPedido AND PedidoItemID = @IdPedidoItem";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", pedidoItem.pedido.PedidoID);
            dataBase.AdicionarParametro("@IdPedidoItem", pedidoItem.PedidoItemID);
            dataBase.AdicionarParametro("@IdProduto", pedidoItem.livro.LivroID);
            dataBase.AdicionarParametro("@Quantidade", pedidoItem.Quantidade);
            dataBase.AdicionarParametro("@ValorUnitario", pedidoItem.ValorUnitario);
            dataBase.AdicionarParametro("@ValorTotal", pedidoItem.ValorTotal);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryAlterar);
        }

        [Obsolete]
        public int Apagar(int IdPedido, int IdPedidoItem)
        {
            string queryApagar = "DELETE FROM tblPedidoItem WHERE PedidoItem = @IdPedido AND PedidoItemID = @IdPedidoItem";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", IdPedido);
            dataBase.AdicionarParametro("@IdPedidoItem", IdPedidoItem);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryApagar);
        }

        [Obsolete]
        public PedidoItemColecao ConsultarTodosItensDoPedido(int IdPedido)
        {
            PedidoItemColecao pedidoItemCollection = new PedidoItemColecao();
            livroController produtoController = new livroController();
            //PedidoController pedidoController = new PedidoController();

            string queryConsulta = "SELECT * FROM tblPedidoItem WHERE PedidoID = @IdPedido ORDER BY PedidoItemID";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", IdPedido);

            DataTable dataTable = dataBase.ExecutarConsulta(CommandType.Text, queryConsulta);

            foreach (DataRow dataRow in dataTable.Rows)
            {
                PedidoItem pedidoItem = new PedidoItem();
               // pedidoItem.pedido = pedidoController.ConsultarPorId(Convert.ToInt32(dataRow["id_pedido"]));
                pedidoItem.livro = produtoController.ConsultarPorId(Convert.ToInt32(dataRow["LivroID"]));
                pedidoItem.PedidoItemID = Convert.ToInt32(dataRow["PedidoItemID"]);
                pedidoItem.Quantidade = Convert.ToInt32(dataRow["Quantidade"]);
                pedidoItem.ValorUnitario = Convert.ToDecimal(dataRow["ValorUnitario"]);
                pedidoItem.ValorTotal = Convert.ToDecimal(dataRow["ValorTotal"]);

                pedidoItemCollection.Add(pedidoItem);
            }
            return pedidoItemCollection;
        }

        [Obsolete]
        public decimal ValorTotalItensItensDoPedido(int IdPedido)
        {
            string query = "SELECT SUM(ValorTotal) FROM tblPedidoItem WHERE PedidoID = @IdPedido";

            dataBase.LimparParametros();
            dataBase.AdicionarParametro("@IdPedido", IdPedido);

            var retorno = dataBase.ExecutarConsultaEsacalar(CommandType.Text, query);

            return Convert.ToDecimal(retorno is DBNull ? 0 : retorno);
        }
    }
}
