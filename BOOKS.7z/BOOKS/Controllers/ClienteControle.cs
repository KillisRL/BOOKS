﻿using BOOKS.Models;
using BOOKS.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;


namespace BOOKS.Controllers
{
    public class ClienteControle
    {
        AcessoDados acessoDados = new AcessoDados();

        [System.Obsolete]
        //metedo alterar
        public int Inserir(Cliente cliente)
        {
            //Variavel local que armazena o comando que será
            //executado no banco de dados
            //O "@" indica para o SQL a utilização de 
            //parametros
            string queryInserir =
                "INSERT INTO tblCliente (ClienteNome, ClienteCPF, Email, " +
                "ClienteTelefone) VALUES (@ClienteNome, " +
                "@ClienteCPF, @Email, @ClienteTelefone)";

            //Limpar qualquer sujeiro do objeto que armezana
            //os parametros
            acessoDados.LimparParametros();

            //Adiona os valores de cada parametro que esta sendo utilizado
            acessoDados.AdicionarParametro("@ClienteNome", cliente.ClienteNome);
            acessoDados.AdicionarParametro("@ClienteCPF", cliente.ClienteCPF);
            acessoDados.AdicionarParametro("@Email", cliente.Email);
            acessoDados.AdicionarParametro("@ClienteTelefone", cliente.ClienteTelefone);

            //Solicita a camada de banco de dados a execução da query
            acessoDados.ExecutarManipulacao(CommandType.Text, queryInserir);
            //Nesse momento o meu comando é executado no banco de dados

            //Executar um comando no banco de dados, para recupear o ID criado
            //pelo Identity
            //SELECT MAX(id_cliente) FROM cliente
            return Convert.ToInt32(acessoDados.ExecutarConsultaEsacalar(
                CommandType.Text, "SELECT MAX(ClienteID) FROM tblCliente"));
        }

        //metodo alterar
        [Obsolete]
        public int Alterar(Cliente cliente) 
        {
            string queryAlterar =
                "UPDATE tblCliente SET " +
                "ClienteNome = @ClienteNome, " +
                "Email = @Email, " +
                "ClienteTelefone = @ClienteTelefone, " +
                "ClienteCPF = @ClienteCPF " +
                "WHERE ClienteID = @ClienteID ";
            acessoDados.LimparParametros();

            acessoDados.AdicionarParametro("@ClienteID", cliente.ClienteID);
            acessoDados.AdicionarParametro("@ClienteNome", cliente.ClienteNome);
            acessoDados.AdicionarParametro("@Email", cliente.Email);
            acessoDados.AdicionarParametro("@ClienteTelefone", cliente.ClienteTelefone);
            acessoDados.AdicionarParametro("@ClienteCPF", cliente.ClienteCPF);

            return acessoDados.ExecutarManipulacao(CommandType.Text, queryAlterar);
        }
        [Obsolete]
        //metodo excluir
        public int Excluir(int ClienteID)
        {
            string queryExcluir =
                "DELETE FROM tblCliente " +
                "WHERE ClienteID = @ClienteID";
            acessoDados.LimparParametros();

            acessoDados.AdicionarParametro("@ClienteID", ClienteID);

            return acessoDados.ExecutarManipulacao(CommandType.Text, queryExcluir);
        }

        public List<Cliente> ConsultarTodos()
        {
            string query = "SELECT * FROM tblCliente"; // Traz todos os clientes

            acessoDados.LimparParametros();
            DataTable dataTable = acessoDados.ExecutarConsulta(CommandType.Text, query);

            List<Cliente> clienteLista = new List<Cliente>();

            foreach (DataRow row in dataTable.Rows)
            {
                Cliente cliente = new Cliente
                {
                    ClienteID = Convert.ToInt32(row["ClienteID"]),
                    ClienteNome = Convert.ToString(row["ClienteNome"]),
                    Email = Convert.ToString(row["Email"]),
                    ClienteTelefone = Convert.ToString(row["ClienteTelefone"]),
                    ClienteCPF = Convert.ToString(row["ClienteCPF"])
                };

                clienteLista.Add(cliente);
            }

            return clienteLista;
        }

        //aqui iremos realizar as consultas
        //filtro pelo ID

        [Obsolete]
        public Cliente ConsultarPorID(int IdCliente)
        {
            string query =
                "SELECT * FROM tblCliente " +
                "WHERE ClienteID = @ClienteID";

            acessoDados.LimparParametros();
            acessoDados.AdicionarParametro("@ClienteID", IdCliente);

            DataTable dataTable = acessoDados.ExecutarConsulta(
                CommandType.Text, query);

            if (dataTable.Rows.Count > 0)
            {
                Cliente cliente = new Cliente();
                //Agora vou indetificar o valor da linha na coluna
                //e atribuir ao objeto
                //Todo dado precisa ser convertido
                //do SQL Server para C#
                cliente.ClienteID = Convert.ToInt32(dataTable.Rows[0]["ClienteID"]);
                cliente.ClienteNome = Convert.ToString(dataTable.Rows[0]["ClienteNome"]);
                cliente.Email = Convert.ToString(dataTable.Rows[0]["Email"]);
                cliente.ClienteTelefone = Convert.ToString(dataTable.Rows[0]["ClienteTelefone"]);
                cliente.ClienteCPF = Convert.ToString(dataTable.Rows[0]["ClienteCPF"]);
                //Adicione o objeto cliente na Coleção de Clientes
                //Ou seja cada linha retorna será um objeto
                //E a Collection tera um objeto de cada linha
                return cliente;
            }
            else
                return null;
        }

        [Obsolete]
        public ClienteColecao ConsultarPorNome(string nome)
        {
            ClienteColecao clienteColecao = new ClienteColecao();
            string query = "SELECT * FROM tblCliente WHERE ClienteNome LIKE '%' + @ClienteNome + '%'";

            acessoDados.LimparParametros();
            acessoDados.AdicionarParametro("@ClienteNome", nome.Trim());

            DataTable dataTable = acessoDados.ExecutarConsulta(CommandType.Text, query);

            // Converte cada linha do DataTable para um objeto Cliente e adiciona à coleção
            foreach (DataRow dataRow in dataTable.Rows)
            {
                Cliente cliente = new Cliente
                {
                    ClienteID = Convert.ToInt32(dataRow["ClienteID"]),
                    ClienteNome = Convert.ToString(dataRow["ClienteNome"]),
                    Email = Convert.ToString(dataRow["Email"]),
                    ClienteTelefone = Convert.ToString(dataRow["ClienteTelefone"]),
                    ClienteCPF = Convert.ToString(dataRow["ClienteCPF"])
                };

                clienteColecao.Add(cliente);
            }

            return clienteColecao;
        }

    }
}

